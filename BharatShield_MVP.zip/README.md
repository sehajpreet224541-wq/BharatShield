# BharatShield MVP

BharatShield is a public-good investor-resilience prototype for the SANGYAN Investor Resilience Hackathon.

## MVP
- Paste a financial message or claim
- Detect explainable warning patterns
- Show verification guidance
- English / Hindi / Punjabi UI
- Privacy-by-design messaging
- No stock tips, predictions, or personalised investment recommendations

## Run
No build system is required.

1. Open `index.html` in a browser.
2. Try one of the demo messages.
3. Change the language selector.
4. Use the app for the hackathon demonstration.

## Important
This MVP uses a transparent, client-side rule engine. It does not claim to make a definitive fraud determination. It is a prototype foundation for adding OCR, official-source verification, and an AI/LLM explanation layer.

## Suggested next development
1. Add screenshot OCR.
2. Add a backend verification service.
3. Add an LLM for claim extraction/explanation with deterministic safety rules around it.
4. Add official-source links and evidence records.
5. Add a lightweight report/grievance guidance flow.
